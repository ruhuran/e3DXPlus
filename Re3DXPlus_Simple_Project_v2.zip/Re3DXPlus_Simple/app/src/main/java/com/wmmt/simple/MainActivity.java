package com.wmmt.simple;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
            5894 | 1024 | 512 | 4096);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.rgb(8, 14, 24));

        TextView title = new TextView(this);
        title.setText("Re3DX+  簡易起動確認版");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView status = new TextView(this);
        status.setText("アプリは正常に起動しました\n\nこれは起動確認用の簡易版です。\nゲーム本体・車両・コース・音声データは\n含まれていないため、レースはプレイできません。\n\n元のRe3DX+プロジェクトのAndroidビルドには\nAndroid SDK / NDK と正規ゲームデータが必要です。");
        status.setTextColor(Color.rgb(210, 220, 235));
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        status.setPadding(32, 28, 32, 24);
        root.addView(status);
        setContentView(root);
    }
}
