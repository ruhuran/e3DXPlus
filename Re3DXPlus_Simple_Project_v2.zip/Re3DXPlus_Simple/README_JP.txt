Re3DX+ 簡易起動確認版（Android端末だけでAPKを作る手順つき）

これは元の湾岸ミッドナイト3DX+本体ではありません。
ゲーム画像・車両・コース・音声・レース機能は含まない、起動確認用の簡易アプリです。

【AndroidスマホだけでAPKを作成する方法】
1. ZIPを解凍できるアプリで、このフォルダを解凍します。
2. Chromeで https://github.com を開き、無料アカウントでログインします。
3. 「New repository」から新しいリポジトリを作成します（例: Re3DXPlus-Simple）。公開/非公開は任意です。
4. リポジトリ画面の「Add file」→「Upload files」を選び、このプロジェクト内のファイルとフォルダをすべてアップロードして「Commit changes」を押します。
   ※ .github フォルダも必ず含めてください。
5. リポジトリの「Actions」タブを開き、「Build Android APK」→「Run workflow」→「Run workflow」を押します。
6. ビルドが成功したら、完了した実行を開き、下部の「Artifacts」から「Re3DXPlus-Simple-APK」をダウンロードします。
7. ZIPを解凍すると app-debug.apk があります。Androidの設定でChromeまたはファイル管理アプリに「不明なアプリのインストール」を許可してからAPKを開きます。

【注意】
・ビルドにはインターネット接続とGitHubアカウントが必要です。
・GitHubの画面表示は更新される場合があります。
・APKはこの簡易アプリのみです。元のゲームを遊べるものではありません。
